<?php

return array(
    'middle' => 'Middle',
    'bottom' => 'Bottom',
);
