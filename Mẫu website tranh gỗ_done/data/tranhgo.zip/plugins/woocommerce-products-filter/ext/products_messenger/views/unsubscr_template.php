                <style>
                    .woof_notice{padding: 30px;background: #ececec;margin: 0 auto;margin-top: 8%;max-width: 400px;text-align: center;}   
                </style>
                <div class="woof_notice"><span>
                <?php echo $text; ?>
                </span>        
                </div>



