jQuery(document).ready(function($){

  $('.image-gallery').lightSlider({ 
        gallery:true, 
        item:1, 
        auto:false, 
        loop:true, 
        thumbItem: 9,
    });

});