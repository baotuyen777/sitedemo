=== Sticky Popup ===
Contributors: numixtech, gauravpadia, asalamwp
Donate link: http://numixtech.com/
Tags: popup,sticky popup,slide-up popup,contact form,social icon,css3,jquery,css3 effects,feedback,popup contact,popup form,social button,advertisement,popup block,advertising popup,popup jquery,fixed menu,float,float anything,float menu,text
Requires at least: 3.6
Tested up to: 4.0
Stable tag: 1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sticky Popup is a simple and easy wordpress plugin used to add popup on fixed position like bottom, left or right side with CSS3 effects.

== Description ==

Sticky Popup is a simple, easy and fully-customizable wordpress plugin used to add popup on fixed position like footer left, footer right, left side or right side with CSS3 effects.

You can display any content like contact form, feedback form, advertising, content, social buttons. Add your content with shortocdes in visual text editor in same way as you edit your wordpress post/page.

Engage your users with this sticky popup plugin.

== Installation ==

**Installation Instruction & Configuration**  	

1. You can use the built-in installer. OR
Download the zip file and extract the contents. Upload the 'sticky-popup' folder to your plugins directory (wp-content/plugins/).

2.Activate the plugin through the 'Plugins' menu in WordPress. 	

3.Go to Settings -> Sticky Popup and set title,color,icon and content

== Screenshots ==

1. Admin settings/options screenshot
2. Sticky Popup closed
3. Sticky Popup open

== Changelog ==

= 1.2 =
* Added feature to enable or disable sticky popup.

= 1.1 =
* Added options for setting title color, header border color, top margin
* Added an option to show popup in posts, pages or home page
* Added an option to show popup at Top Left or Top Right position

= 1.0 =
* Initial Relaese