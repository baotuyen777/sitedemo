<p style="color: #43cb83; font-size:36px; margin-top:0px; padding-top:0px;">RATE PLUGIN &amp; GET A 30% DISCOUNT!!!</p>
<div style="float: left;"><img src="<?php echo plugin_dir_url( __FILE__ ); ?>img/banner.png" alt="" width="350" /></div>
<div style="padding-left: 20px; padding-right:20px; float: left; font-family: Tahoma; width: 60%; font-size:18px;">	
	<p style="font-size:18px;">Sweet deal for you. Spend 1 minute, rate our free plugin at Wordpress.org and get a third off the Wow version of your choice.</p>
	<ol>
		<li style="margin-bottom:15px;">Leave a 5 star rating and add a comment at the <a href="https://wordpress.org/plugins/float-menu/reviews/" target="_blank" style="color: #43cb83;">plugin's wordpress.org page</a></li>
		<li style="margin-bottom:15px;">Send us an email to <span style="color: #43cb83;">support@wow-company.com</span> or via <a href='admin.php?page=<?php echo $pluginname;?>&tool=support' title="Support page">Support page</a> with the subject 'Discount for rating' , with the nickname you used to leave the rating.</li>
		<li style="margin-bottom:20px;">We will send you back a 30% discount code that you can use to purchase any Wow version at <a href="https://wow-estore.com" target="_blank" style="color: #43cb83;">wow-estore.com</a></li>
	</ol>
</div>