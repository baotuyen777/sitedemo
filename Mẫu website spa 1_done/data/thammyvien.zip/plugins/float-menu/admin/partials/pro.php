<div class="wow-admin-col">	
	<div class="wow-admin-col-6">
		<p style="color: #43cb83; font-size:24px; margin-top:0px; padding-top:0px;">ADDITIONAL OPTIONS IN PRO VERSION</p>
	</div>
	<div class="wow-admin-col-6 right">
		<a href="https://wow-estore.com/item/float-menu-pro/" target="_blank" class="wow-btn">GET PRO VERSION</a>
	</div>
</div>

<div class="wow-admin-col" style="font-size:18px;">
	
	<div class="wow-admin-col-6 wow-futures">	
		<b>Menu setting:</b>
		<ul>
			<li>Align</li>
			<li>Shape</li>
			<li>Label Effect</li>
			<li>Label Speed</li>			
		</ul>	
		<b>Sub Menu setting:</b>
		<ul>
			<li>Sub Position</li>
			<li>Sub Space</li>
			<li>Sub Effect</li>
			<li>Sub Speed</li>			
		</ul>	
		<b>Popup setting:</b>
		<ul>
			<li>Horizontal position</li>
			<li>Vertical position</li>
			<li>Corners</li>
			<li>Color</li>			
		</ul>
	</div>
	<div class="wow-admin-col-6 wow-futures">
		<b>Item setting:</b>
		<ul>
			<li>Built-in social share, print and popup buttons</li>
			<li>Built-in user links: LogIn, LogOut, Register, Lostpassword</li>
			<li>Sub item</li>
			<li>Custom icon</li>			
		</ul>
		<b>Other settings:</b>
		<ul>  
			
			<li>Show for users : for authorized or unauthorized site users;</li>
			<li>Depending on the language</li>			
			<li>Float Menu display can be carried out on all the pages in all the website publications indicating the specified exceptions, choosing pages/posts by the set id or inserted shortcode at the same time.</li>
		</ul>
	</div>
</div>
<p style="color: #43cb83; font-size:36px; margin-top:0px; padding-top:0px;">RATE PLUGIN &amp; GET A 30% DISCOUNT!!!</p>
<div style="float: left;"><img src="<?php echo plugin_dir_url( __FILE__ ); ?>img/banner.png" alt="" width="350" /></div>
<div style="padding-left: 20px; padding-right:20px; float: left; font-family: Tahoma; width: 60%; font-size:18px;">
	
	<p style="font-size:18px;">Sweet deal for you. Spend 1 minute, rate our free plugin at Wordpress.org and get a third off the Wow version of your choice.</p>
	<ol>
		<li style="margin-bottom:15px;">Leave a 5 star rating and add a comment at the <a href="https://wordpress.org/plugins/float-menu/reviews/" target="_blank" style="color: #43cb83;">plugin's wordpress.org page</a></li>
		<li style="margin-bottom:15px;">Send us an email to <span style="color: #43cb83;">support@wow-company.com</span> or via <a href='admin.php?page=<?php echo $pluginname;?>&tool=support' title="Support page">Support page</a> with the subject 'Discount for rating' , with the nickname you used to leave the rating.</li>
		<li style="margin-bottom:20px;">We will send you back a 30% discount code that you can use to purchase any Wow version at <a href="https://wow-estore.com" target="_blank" style="color: #43cb83;">wow-estore.com</a></li>
	</ol>
</div>
