<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wow_admin_signup">
	Want to know about updates to this plugin without having to log into your site every time? Want to know about other cool plugins we make? Want to get attractive DISCOUNTS for the premium extensions? Add your email and we'll add you to our very rare mail-outs.
	<p/>
	<!-- Begin MailChimp Signup Form -->
	<div id="mc_embed_signup">
		<form action="https://wow-estore.us15.list-manage.com/subscribe/post?u=46ce980680ab6ad7ae51a3c23&amp;id=e7ffad4405" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
			<div class="mc-field-group">
				
				<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Email Address *"> <button type="submit" name="subscribe" id="mc-embedded-subscribe" class="wow_admin_green">Sign Up!</button>
			</div>
			<div id="mce-responses" class="clear">
				<div class="response" id="mce-error-response" style="display:none"></div>
				<div class="response" id="mce-success-response" style="display:none"></div>
			</div>   
			<div class="clear"></div>
		</form>
	</div>
	<!--End mc_embed_signup-->	
</div>

<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fwowaffect%2F&tabs=timeline&width=800&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=263881116956615" width="550" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

