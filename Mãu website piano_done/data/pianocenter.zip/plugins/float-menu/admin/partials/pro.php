<div class="wow-admin-col">	
	<div class="wow-admin-col-12">
		<p style="font-size:36px; margin-top:15px; padding-top:0px;">ADDITIONAL OPTIONS IN PRO VERSION <br/>
			<a href="https://wow-estore.com/item/float-menu-pro/" target="_blank" class="wow-btn">GET PRO VERSION <i class="fa fa-download"></i></a> <a href="https://wow-estore.com/item-preview/float-menu-pro/" target="_blank" class="wow-btn">DEMO PRO VERSION <i class="fa fa-eye"></i></a>
		</p>
	</div>	
</div>

<div class="wow-admin-col" style="font-size:18px;">
	
	<div class="wow-admin-col-6 wow-futures">	
		<b>Menu setting:</b>
		<ul>
			<li>Align</li>
			<li>Shape</li>
			<li>Label Effect</li>
			<li>Label Speed</li>			
		</ul>	
		<b>Sub Menu setting:</b>
		<ul>
			<li>Sub Position</li>
			<li>Sub Space</li>
			<li>Sub Effect</li>
			<li>Sub Speed</li>			
		</ul>	
		<b>Popup setting:</b>
		<ul>
			<li>Horizontal position</li>
			<li>Vertical position</li>
			<li>Corners</li>
			<li>Color</li>			
		</ul>
	</div>
	<div class="wow-admin-col-6 wow-futures">
		<b>Item setting:</b>
		<ul>
			<li>Built-in social share, print and popup buttons</li>
			<li>Built-in user links: LogIn, LogOut, Register, Lostpassword</li>
			<li>Sub item</li>
			<li>Custom icon</li>			
		</ul>
		<b>Other settings:</b>
		<ul>  
			
			<li>Show for users : for authorized or unauthorized site users;</li>
			<li>Depending on the language</li>			
			<li>Float Menu display can be carried out on all the pages in all the website publications indicating the specified exceptions, choosing pages/posts by the set id or inserted shortcode at the same time.</li>
		</ul>
	</div>
</div>
<p style="color: #43cb83; font-size:36px; margin-top:0px; padding-top:0px;">THANK YOU FOR CHOOSING OUR PLUGIN!!!</p>
<div style="float: left;"><img src="<?php echo plugin_dir_url( __FILE__ ); ?>img/thankyou.png" alt="" width="250" /></div>
<div style="padding-left: 20px; padding-right:20px; float: left; font-family: Tahoma; width: 60%; font-size:18px;">
<p style="font-size:18px;">We will be very grateful if you <a href="https://wordpress.org/plugins/float-menu/" target="_blank"><b/>leave a review about the plugin</b></a>.</p>
<p style="font-size:18px;">If you have suggestions on how to improve the plugin or create a new plugin, write to us via the <a href="admin.php?page=<?php echo $pluginname;?>&tool=support" target="_blank"><b>support form</b></a></p>					
<p style="font-size:18px;">We really appreciate your reviews and suggestions for improving the plugin.</p>

<em><b style="color: #43cb83;">Best Regards</b>,<br/>						
	<a href="https://wow-estore.com/" target="_blank">Wow-Company Team</a><br/>
	Dmytro Lobov<br/>
	<a href="mailto:support@wow-company.com">support@wow-company.com</a>
</em>
</div>
