
 ### v0.11.2 - 2018-03-05 
 **Changes:** 
 * Improve popup sidebar layout.
 
 ### v0.11.1 - 2018-02-24 
 **Changes:** 
 * Add recommendation boxes in the menu icon popup.
 
 ### v0.11.0 - 2018-01-05 
 **Changes:** 
 * Change ownership to ThemeIsle.
* Improves compatibility with various ThemeIsle products.
 
