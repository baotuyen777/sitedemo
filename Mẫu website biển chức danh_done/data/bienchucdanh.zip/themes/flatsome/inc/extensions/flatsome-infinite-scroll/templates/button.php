<p class="text-center">
	<button class="view-more-button products-archive button primary hidden"><?php esc_html_e( 'View more', 'flatsome' ); ?></button>
</p>
