<?php

class WCML_Multi_Currency_UI{

}