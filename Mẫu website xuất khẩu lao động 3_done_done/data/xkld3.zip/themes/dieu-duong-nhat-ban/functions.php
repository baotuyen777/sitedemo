<?php
// Add custom Theme Functions here
// 

add_filter( 'category_description', 'do_shortcode' );