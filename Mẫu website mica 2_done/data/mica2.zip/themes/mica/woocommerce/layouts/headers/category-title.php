<div class="row-header">
    <?php echo do_shortcode('[block id="header-page"]'); ?>
</div>