<?php
// Add custom Theme Functions here
// 
// Thay chữ trong trang danh mục sản phẩm
  
add_filter( 'woocommerce_product_add_to_cart_text', 'woo_archive_custom_cart_button_text' ); // 2.1 +
function woo_archive_custom_cart_button_text() {
return __( 'Mua ngay', 'woocommerce' );
}
  
//Thay chữ trong trang chi tiết của bài viết
  
add_filter( 'woocommerce_product_single_add_to_cart_text', 'woo_custom_cart_button_text' ); // 2.1 +
function woo_custom_cart_button_text() {
return __( 'Mua ngay', 'woocommerce' );
}