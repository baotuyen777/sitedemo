<?php

return array(
	'collapse' => 'Collapse',
	'xsmall' => 'X Small',
    'small' => 'Small',
    'normal' => 'Normal',
    'large' => 'Large',
)
?>